using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Elearning
{
    #region Users_courses
    public class Users_courses
    {
        #region Member Variables
        protected int _users_courses_id;
        protected int _user_id;
        protected string _couces_buy;
        protected string _user_wish_list;
        #endregion
        #region Constructors
        public Users_courses() { }
        public Users_courses(int user_id, string couces_buy, string user_wish_list)
        {
            this._user_id=user_id;
            this._couces_buy=couces_buy;
            this._user_wish_list=user_wish_list;
        }
        #endregion
        #region Public Properties
        public virtual int Users_courses_id
        {
            get {return _users_courses_id;}
            set {_users_courses_id=value;}
        }
        public virtual int User_id
        {
            get {return _user_id;}
            set {_user_id=value;}
        }
        public virtual string Couces_buy
        {
            get {return _couces_buy;}
            set {_couces_buy=value;}
        }
        public virtual string User_wish_list
        {
            get {return _user_wish_list;}
            set {_user_wish_list=value;}
        }
        #endregion
    }
    #endregion
}